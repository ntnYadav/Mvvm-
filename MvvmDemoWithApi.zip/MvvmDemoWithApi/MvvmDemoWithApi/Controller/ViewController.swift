//
//  ViewController.swift
//  MvvmDemoWithApi
//
//  Created by Admin on 21/06/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
struct InterviewCandidate {
    var isiOS:Bool?
    
    lazy var iOSResumeDescription: String = {
        return "I am an iOS developer"
    }()
    lazy var androidResumeDescription: String = {
        return "I am an android developer"
    }()
}

struct  lazyStruct {
    lazy var date1 : NSDate = {
        return NSDate()
    }()
    var date2 : NSDate = {
        return NSDate()
    }()
}
class ViewController: UIViewController {
    @IBOutlet weak var tblDemo: UITableView!
    
    lazy var viewModel: demoViewModel = {
        return demoViewModel()
    }()
    
    
    
    var variable1 : Int = 0 {
        didSet{ // After storing the new Value.
            print("didSet called")
            variable1 = 4
            print("will\(variable1)")

        }
        willSet(newValue){ //Before storing the value.
            print("willSet called")
        }
    }
    
   

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // to Willset and didset example
        var userObj = InterviewCandidate()
        print("First User = \(userObj.iOSResumeDescription)")
        
        var objLazy = lazyStruct()
        sleep(5)
        print("Without Lazy == \(objLazy.date2)")
        print("With lazy == \(objLazy.date1)")

        
        print("we are going to add 3")
        variable1 = 3
        print("will\(variable1)")
        print("did\(variable1)")
        print("we added 3")
        print("we added 3")
        
        initVM()
       
        // Polymorphism
        var animal = Animal()
        print(animal.makeNoise())

        animal = Cat()
        print(animal.makeNoise())
        
        animal = Dog()
        print(animal.makeNoise())

        
        // Encapsulation
        let calculation = Maths(a: 2, b: 3)
        calculation.add()
        calculation.displayResult()
        
        // Protocol Extension
        let cat = Cat()
        cat.maximumAge // 20
        cat.feed()
        
        let dog = Dog()
        dog.maximumAge // 25
        dog.feed()
    }
    func initVM() {
        
        viewModel.reloadTableViewClosure = { [weak self] () in
            DispatchQueue.main.async {
                self?.tblDemo.reloadData()
            }
        }
        viewModel.initFetch()
    }
}
extension ViewController: UITableViewDelegate, UITableViewDataSource {
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "demoTableViewCell", for: indexPath) as? DemoTableViewCell else {
                fatalError("Cell does not exist in storyboard")
            }
            
            let cellVM = viewModel.getCellViewModel( at: indexPath )

            cell.repoNameText.text = cellVM.name
            cell.repoDescText.text = cellVM.desc

            cell.repoCounterText.text = "Star: \(cellVM.starCount) Fork: \(cellVM.forkCount) URL: \(cellVM.url)"
            
            return cell
        }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return viewModel.numberOfCells
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 190.0
        }
        
        
}
//Polymorphism

class Animal {
    lazy var lazyUser: String = {
        return "I am Ios developer"
    }()
    
    lazy var lazyV1 : String = {
        return "i am Android Developer"
    }()
    
    func makeNoise()
    {
        print("Durrr")
    }
}

class Cat : Animal
{
    override func makeNoise()
    {
        print("Meoooowwwww")
    }
}

class Dog : Animal
{
    override func makeNoise()
    {
        print("Woooooof")
    }
    // protocol methods
   
}

extension Animal {
    var maximumAge: Int {
        return 20
    }
    
    func feed() {
        print("eating")
    }
}

///  Enscapsulation
class Maths {//1
    
    //2
    let a: Int!
    let b: Int!
    final var result: Int?
    private var result2: Int?
    fileprivate var result3: Int?

    //3
    init(a: Int,b: Int) {
        self.a = a
        self.b = b
    }
    
    //4
    func add() {
        result = a + b
        result2 = a * b
        result3 = a / b
    }
    
    //5
    func displayResult() {
        print("Result - \(result)")
        print("Result - \(result2)")
        print("Result - \(result3)")

    }
}


