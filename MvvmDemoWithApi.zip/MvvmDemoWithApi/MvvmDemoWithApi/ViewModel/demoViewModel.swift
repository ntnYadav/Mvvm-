//
//  demoViewModel.swift
//  MvvmDemoWithApi
//
//  Created by Admin on 21/06/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation
class demoViewModel {
    
    var apiService:ApiService
    private var repos:[DemoModel] = [DemoModel]()
    
    private var cellViewModelFirst:[DemoModel] = [DemoModel]() {
        didSet {
            self.reloadTableViewClosure?()
        }
    }
    var numberOfCells: Int {
        return cellViewModelFirst.count
    }
    
    var reloadTableViewClosure: (()->())?
    
    init(apiService:ApiService = ApiService()) {
        self.apiService = apiService
    }
    
    func initFetch() {
        apiService.fetchAllRepo { (success, repos, error) in
            if(error == "") {
                self.processFetchedRepo(repos: repos)
            } else {
                print("Error")
            }
        }
    }
    
    func getCellViewModel( at indexPath: IndexPath ) -> DemoModel {
        return cellViewModelFirst[indexPath.row]
    }
    
    func createCellViewModel( repo: DemoModel ) -> DemoModel {
        
        return DemoModel( name: repo.name,url: repo.url,desc: repo.desc!, starCount: repo.starCount,forkCount:repo.forkCount)
    }
    
    private func processFetchedRepo( repos: [DemoModel] ) {
        self.repos = repos // Cache
        var vms = [DemoModel]()
        for repo in repos {
            vms.append( createCellViewModel(repo: repo) )
        }
        self.cellViewModelFirst = vms
    }
    
}
